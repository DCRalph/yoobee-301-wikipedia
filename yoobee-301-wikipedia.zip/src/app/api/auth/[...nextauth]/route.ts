import { handlers } from "~/server/auth";

export const { GET, POST } = handlers;
