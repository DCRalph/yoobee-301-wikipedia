import Home from "./Home";
export default async function page() {
  return <Home />;
}
